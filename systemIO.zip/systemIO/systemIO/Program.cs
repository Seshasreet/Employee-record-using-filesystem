﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace systemIO
{
    class Program
    {
        static void Main(string[] args)
        {
            string filename = @"C:\Users\Pooja Rani\Desktop\Employee.txt";
            string filename1 = @"C:\Users\Pooja Rani\Desktop\Department.txt";
            string filename2 = @"C:\Users\Pooja Rani\Desktop\projects.txt";
            List<employee> emprec = new List<employee>();
            List<department> deprec = new List<department>();
            List<projects> prorec = new List<projects>();
            int ch;

            do
            {
                Console.WriteLine("1 Employee Record");
                Console.WriteLine("2 Depatrment Record");
                Console.WriteLine("3 Project Record");
                Console.WriteLine("4 Insert in to the Employee File");
                Console.WriteLine("5 Insert in to the Department File");
                Console.WriteLine("6 Insert in to the Project File");
                Console.WriteLine("7 Get project Info by Employee ID");
                Console.WriteLine("8 Get Employee Info by Depart ID");
                Console.WriteLine("9 Exit");
                Console.Write("Enter the choice = ");
                ch = int.Parse(Console.ReadLine());

                switch (ch)
                {
                    case 1:
                        employee emp = new employee();
                        emprec.Add(emp);
                        break;
                    case 2:
                        department dep = new department();
                        deprec.Add(dep);
                        break;
                    case 3:
                        projects pro = new projects();
                        prorec.Add(pro);
                        break;
                    case 4:
                        try
                        {
                            using (StreamWriter writer = new StreamWriter(filename, true))
                            {
                                foreach (employee e in emprec)
                                {
                                    writer.Write(e.displayemp() + "\n");
                                }
                            }
                        }
                        catch (Exception e1)
                        {
                            Console.WriteLine(e1.Message);
                        }
                        break;
                    case 5:
                        try
                        {
                            using (StreamWriter writer = new StreamWriter(filename1, true))
                            {
                                foreach (department d in deprec)
                                {
                                    writer.Write(d.displaydep() + "\n");
                                }
                            }
                        }
                        catch (Exception e1)
                        {
                            Console.WriteLine(e1.Message);
                        }
                        break;
                    case 6:
                        try
                        {
                            using (StreamWriter writer = new StreamWriter(filename2, true))
                            {
                                foreach (projects p in prorec)
                                {
                                    writer.Write(p.displayproj() + "\n");
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            Console.WriteLine(e.Message);
                        }
                        break;
                    case 7:
                        Console.WriteLine("Enter the Employee id");
                        string ID = Console.ReadLine();
                        Connectfile.projectbyempID(ID, filename, filename2);
                        break;
                    case 8:
                        Console.WriteLine("Enter the Department ID");
                        string ID1 = Console.ReadLine();
                        Connectfile.EmpInfobyDeptID(ID1, filename, filename1);
                        break;
                    case 9: Console.WriteLine("U have been logged out"); break;
                    default: Console.WriteLine("Invalid choice"); break;
                }

            } while (ch != 9);
        }
    }
}
